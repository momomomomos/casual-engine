from loguru import logger
import pygame, os
logger.info('All libraries initialized')